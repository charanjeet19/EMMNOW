<?php


class mo_twitch
{
    public $color="#6441A5";
}
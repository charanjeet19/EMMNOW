<?php


class mo_kakao
{
    public $color="#F9E000";
}
<?php


class mo_flickr
{
    public $color="#FF2F96";
}
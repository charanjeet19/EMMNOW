<?php


class mo_line
{
    public $color="#00B900";
}
<?php


class mo_odnoklassniki
{
    public $color="#F58220";
}
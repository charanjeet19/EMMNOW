<?php


class mo_discord
{
    public $color="#7289DA";
}
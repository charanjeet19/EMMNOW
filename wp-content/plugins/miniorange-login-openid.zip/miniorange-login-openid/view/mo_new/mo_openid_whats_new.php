<?php

function mo_openid_miniorange_new(){
 ?>
    <div style="width: 100%">
        <div style="width: 50%; float: left">
            <div style="margin-left:10px;margin-top:20px; height: auto" class="mo_openid_support_layout">
                <div>
                    <p><?php echo mo_sl('Do you want to make your <b>website more secure');?></b> <?php echo mo_sl('by Brute Force attack, Spam Protection etc? Try out our Plugin.');?></p>
                    <script type='text/javascript'>
                        <!--//--><![CDATA[//><!--
                        !function(a,b) {"use strict";function c() {if(!e) {e=!0;var a,c,d,f,g=-1!==navigator.appVersion.indexOf("MSIE 10"),h=!!navigator.userAgent.match(/Trident.*rv:11\./),i=b.querySelectorAll("iframe.wp-embedded-content");for(c=0;c<i.length;c++){if(d=i[c],!d.getAttribute("data-secret"))f=Math.random().toString(36).substr(2,10),d.src+="#?secret="+f,d.setAttribute("data-secret",f);if(g||h)a=d.cloneNode(!0),a.removeAttribute("security"),d.parentNode.replaceChild(a,d)}}}var d=!1,e=!1;if(b.querySelector)if(a.addEventListener)d=!0;if(a.wp=a.wp||{},!a.wp.receiveEmbedMessage)if(a.wp.receiveEmbedMessage=function(c){var d=c.data;if(d)if(d.secret||d.message||d.value)if(!/[^a-zA-Z0-9]/.test(d.secret)){var e,f,g,h,i,j=b.querySelectorAll('iframe[data-secret="'+d.secret+'"]'),k=b.querySelectorAll('blockquote[data-secret="'+d.secret+'"]');for(e=0;e<k.length;e++)k[e].style.display="none";for(e=0;e<j.length;e++)if(f=j[e],c.source===f.contentWindow){if(f.removeAttribute("style"),"height"===d.message){if(g=parseInt(d.value,10),g>1e3)g=1e3;else if(~~g<200)g=200;f.height=g}if("link"===d.message)if(h=b.createElement("a"),i=b.createElement("a"),h.href=f.getAttribute("src"),i.href=d.value,i.host===h.host)if(b.activeElement===f)a.top.location.href=d.value}else;}},d)a.addEventListener("message",a.wp.receiveEmbedMessage,!1),b.addEventListener("DOMContentLoaded",c,!1),a.addEventListener("load",c,!1)}(window,document);
                        //--><!]]>
                    </script>
                    <iframe sandbox="allow-scripts" security="restricted" target="_blank" src="https://wordpress.org/plugins/wp-security-pro/embed/" width="95%" height="230" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" class="wp-embedded-content"></iframe>
                </div>
            </div>
        </div>
        <div style="width: 50%; display: inline-block">
            <div style="margin-left:10px;margin-top:20px; height: auto" class="mo_openid_support_layout">
                <div>
                    <p><?php echo mo_sl('Looking for');?> <b><?php echo mo_sl('WordPress REST API Authentication?');?></b> <?php echo mo_sl('Try out our new Plugin which secures rest API access for unauthorized users using OAuth 2.0, Basic Auth, jwt, Bearer Token.');?></p>
                    <script type='text/javascript'>
                        <!--//--><![CDATA[//><!--
                        !function(a,b){"use strict";function c(){if(!e){e=!0;var a,c,d,f,g=-1!==navigator.appVersion.indexOf("MSIE 10"),h=!!navigator.userAgent.match(/Trident.*rv:11\./),i=b.querySelectorAll("iframe.wp-embedded-content");for(c=0;c<i.length;c++){if(d=i[c],!d.getAttribute("data-secret"))f=Math.random().toString(36).substr(2,10),d.src+="#?secret="+f,d.setAttribute("data-secret",f);if(g||h)a=d.cloneNode(!0),a.removeAttribute("security"),d.parentNode.replaceChild(a,d)}}}var d=!1,e=!1;if(b.querySelector)if(a.addEventListener)d=!0;if(a.wp=a.wp||{},!a.wp.receiveEmbedMessage)if(a.wp.receiveEmbedMessage=function(c){var d=c.data;if(d)if(d.secret||d.message||d.value)if(!/[^a-zA-Z0-9]/.test(d.secret)){var e,f,g,h,i,j=b.querySelectorAll('iframe[data-secret="'+d.secret+'"]'),k=b.querySelectorAll('blockquote[data-secret="'+d.secret+'"]');for(e=0;e<k.length;e++)k[e].style.display="none";for(e=0;e<j.length;e++)if(f=j[e],c.source===f.contentWindow){if(f.removeAttribute("style"),"height"===d.message){if(g=parseInt(d.value,10),g>1e3)g=1e3;else if(~~g<200)g=200;f.height=g}if("link"===d.message)if(h=b.createElement("a"),i=b.createElement("a"),h.href=f.getAttribute("src"),i.href=d.value,i.host===h.host)if(b.activeElement===f)a.top.location.href=d.value}else;}},d)a.addEventListener("message",a.wp.receiveEmbedMessage,!1),b.addEventListener("DOMContentLoaded",c,!1),a.addEventListener("load",c,!1)}(window,document);
                        //--><!]]>
                    </script>
                    <iframe sandbox="allow-scripts" security="restricted" target="_blank" src="https://wordpress.org/plugins/wp-rest-api-authentication/embed/" width="95%" height="230" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" class="wp-embedded-content"></iframe>
                </div>
            </div>
        </div>
    </div><br/>
    <div style="width: 100%">
        <div style="width: 50%; float: left">
            <div style="margin-left:10px;margin-top:20px; height: auto" class="mo_openid_support_layout">
                <div>
                    <p><?php echo mo_sl('Looking for ');?><b><?php echo mo_sl('WordPress OAuth Single Sign On?');?></b> <?php echo mo_sl('Try out our new Plugin which allows login (Single Sign On) into WordPress with your Azure AD, AWS Cognito, Invision Community, Slack, Discord or other custom OAuth 2.0 / OpenID Connect providers');?>.</p>
                    <script type='text/javascript'>
                        <!--//--><![CDATA[//><!--
                        !function(a,b){"use strict";function c(){if(!e){e=!0;var a,c,d,f,g=-1!==navigator.appVersion.indexOf("MSIE 10"),h=!!navigator.userAgent.match(/Trident.*rv:11\./),i=b.querySelectorAll("iframe.wp-embedded-content");for(c=0;c<i.length;c++){if(d=i[c],!d.getAttribute("data-secret"))f=Math.random().toString(36).substr(2,10),d.src+="#?secret="+f,d.setAttribute("data-secret",f);if(g||h)a=d.cloneNode(!0),a.removeAttribute("security"),d.parentNode.replaceChild(a,d)}}}var d=!1,e=!1;if(b.querySelector)if(a.addEventListener)d=!0;if(a.wp=a.wp||{},!a.wp.receiveEmbedMessage)if(a.wp.receiveEmbedMessage=function(c){var d=c.data;if(d)if(d.secret||d.message||d.value)if(!/[^a-zA-Z0-9]/.test(d.secret)){var e,f,g,h,i,j=b.querySelectorAll('iframe[data-secret="'+d.secret+'"]'),k=b.querySelectorAll('blockquote[data-secret="'+d.secret+'"]');for(e=0;e<k.length;e++)k[e].style.display="none";for(e=0;e<j.length;e++)if(f=j[e],c.source===f.contentWindow){if(f.removeAttribute("style"),"height"===d.message){if(g=parseInt(d.value,10),g>1e3)g=1e3;else if(~~g<200)g=200;f.height=g}if("link"===d.message)if(h=b.createElement("a"),i=b.createElement("a"),h.href=f.getAttribute("src"),i.href=d.value,i.host===h.host)if(b.activeElement===f)a.top.location.href=d.value}else;}},d)a.addEventListener("message",a.wp.receiveEmbedMessage,!1),b.addEventListener("DOMContentLoaded",c,!1),a.addEventListener("load",c,!1)}(window,document);
                        //--><!]]>
                    </script>
                    <iframe sandbox="allow-scripts" security="restricted" target="_blank" src="https://wordpress.org/plugins/miniorange-login-with-eve-online-google-facebook/embed/" width="95%" height="230" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" class="wp-embedded-content"></iframe>
                </div>
            </div>
        </div>
        <div style="width: 50%; display: inline-block">
            <div style="margin-left:10px;margin-top:20px; height: auto" class="mo_openid_support_layout">
                <div>
                    <p><?php echo mo_sl('Looking for');?> <b><?php echo mo_sl('WordPress Two Factor Authentication');?></b><?php echo mo_sl( 'Try out our 2FA Plugin which is simple & easy 2FA setup with any App supporting TOTP algorithm like Google, Authy, LastPass Authenticator & other 2FA methods.');?></p>
                    <script type='text/javascript'>
                        <!--//--><![CDATA[//><!--
                        !function(a,b) {"use strict";function c() {if(!e) {e=!0;var a,c,d,f,g=-1!==navigator.appVersion.indexOf("MSIE 10"),h=!!navigator.userAgent.match(/Trident.*rv:11\./),i=b.querySelectorAll("iframe.wp-embedded-content");for(c=0;c<i.length;c++){if(d=i[c],!d.getAttribute("data-secret"))f=Math.random().toString(36).substr(2,10),d.src+="#?secret="+f,d.setAttribute("data-secret",f);if(g||h)a=d.cloneNode(!0),a.removeAttribute("security"),d.parentNode.replaceChild(a,d)}}}var d=!1,e=!1;if(b.querySelector)if(a.addEventListener)d=!0;if(a.wp=a.wp||{},!a.wp.receiveEmbedMessage)if(a.wp.receiveEmbedMessage=function(c){var d=c.data;if(d)if(d.secret||d.message||d.value)if(!/[^a-zA-Z0-9]/.test(d.secret)){var e,f,g,h,i,j=b.querySelectorAll('iframe[data-secret="'+d.secret+'"]'),k=b.querySelectorAll('blockquote[data-secret="'+d.secret+'"]');for(e=0;e<k.length;e++)k[e].style.display="none";for(e=0;e<j.length;e++)if(f=j[e],c.source===f.contentWindow){if(f.removeAttribute("style"),"height"===d.message){if(g=parseInt(d.value,10),g>1e3)g=1e3;else if(~~g<200)g=200;f.height=g}if("link"===d.message)if(h=b.createElement("a"),i=b.createElement("a"),h.href=f.getAttribute("src"),i.href=d.value,i.host===h.host)if(b.activeElement===f)a.top.location.href=d.value}else;}},d)a.addEventListener("message",a.wp.receiveEmbedMessage,!1),b.addEventListener("DOMContentLoaded",c,!1),a.addEventListener("load",c,!1)}(window,document);
                        //--><!]]>
                    </script>
                    <iframe sandbox="allow-scripts" security="restricted" target="_blank" src="https://wordpress.org/plugins/miniorange-2-factor-authentication/embed/" width="95%" height="230" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" class="wp-embedded-content"></iframe>
                </div>
            </div>
        </div>
    </div><br/>
    <div style="width: 100%">
        <div style="width: 50%; float: left">
            <div style="margin-left: 10px ;margin-top:20px; height: 357px" class="mo_openid_support_layout">
                <div>
                    <p><?php echo mo_sl('Looking for a');?> <b><?php echo mo_sl('Custom Registration Form');?></b>? <?php echo mo_sl('Try our new <b>Social Login Integration Add-on');?></b>.</p>
                    <div style="width:95%; height:285px; border: 1px solid lightgrey;">
                        <div style="width: 100%; height: 70px; margin-top: 15px">
                            <div style=" margin-left: 20px; width: 20%; float: left"><a href="admin.php?page=mo_openid_settings_addOn" target="_blank"><img style="height:60px" src="<?php echo dirname(plugin_url). '/miniOrange_logo.png'?>"></a></div>
                            <div style="width: 70%; float:right">
                                <h1 style="margin: 0 0 15px; font-weight: 600; font-size: 22px; line-height: 1.3;">
                                    <a class="mo-pugin-add-link-sl mo-add-hover" href="admin.php?page=mo_openid_settings_addOn" target="_blank" style="font-size: large"><?php echo mo_sl('Social Login Integration Add-on');?></a>
                                    <a class="mo-pugin-add-comp-link-sl"><?php echo mo_sl('by');?> </a>
                                    <a class="mo-pugin-add-comp-link-sl mo-add-hover" href="https://www.miniorange.com/" target="_blank"><?php echo mo_sl('miniorange');?></a>
                                </h1>
                            </div>
                        </div>
                        <p style="margin-left: 10px; font-size: 14px"><?php echo mo_sl('Custom Registration Form Add-On helps you to integrate details of new as well as existing users. You can add as many fields as you want including the one which are returned by social sites at time of registration');?>.</p>
                        <span class="tested-with" style="margin-left: 3%">
                            <i class="dashicons dashicons-wordpress-alt"></i><?php echo mo_sl('Tested with 5.3');?>
                        </span>
                        <a href="admin.php?page=mo_openid_settings_addOn" target="_blank"><button style="margin-right: 25px; align-content: center; float: right; height: 30px" class="button button-primary button-large"><b><?php echo mo_sl('Get this plugin');?></b></button></a><br><br>
                    </div>
                </div>
            </div>
        </div>
        <div style="width: 50%; display: inline-block">
            <div style="margin-left:10px;margin-top:20px; height: auto" class="mo_openid_support_layout">
                <div>
                    <p><?php echo mo_sl('Looking for');?> <b><?php echo mo_sl('OTP Verification');?></b> <?php echo mo_sl('along with Social Login? Try our OTP Plugin.');?></p>
                    <script type='text/javascript'>
                        <!--//--><![CDATA[//><!--
                        !function(a,b) {"use strict";function c() {if(!e) {e=!0;var a,c,d,f,g=-1!==navigator.appVersion.indexOf("MSIE 10"),h=!!navigator.userAgent.match(/Trident.*rv:11\./),i=b.querySelectorAll("iframe.wp-embedded-content");for(c=0;c<i.length;c++){if(d=i[c],!d.getAttribute("data-secret"))f=Math.random().toString(36).substr(2,10),d.src+="#?secret="+f,d.setAttribute("data-secret",f);if(g||h)a=d.cloneNode(!0),a.removeAttribute("security"),d.parentNode.replaceChild(a,d)}}}var d=!1,e=!1;if(b.querySelector)if(a.addEventListener)d=!0;if(a.wp=a.wp||{},!a.wp.receiveEmbedMessage)if(a.wp.receiveEmbedMessage=function(c){var d=c.data;if(d)if(d.secret||d.message||d.value)if(!/[^a-zA-Z0-9]/.test(d.secret)){var e,f,g,h,i,j=b.querySelectorAll('iframe[data-secret="'+d.secret+'"]'),k=b.querySelectorAll('blockquote[data-secret="'+d.secret+'"]');for(e=0;e<k.length;e++)k[e].style.display="none";for(e=0;e<j.length;e++)if(f=j[e],c.source===f.contentWindow){if(f.removeAttribute("style"),"height"===d.message){if(g=parseInt(d.value,10),g>1e3)g=1e3;else if(~~g<200)g=200;f.height=g}if("link"===d.message)if(h=b.createElement("a"),i=b.createElement("a"),h.href=f.getAttribute("src"),i.href=d.value,i.host===h.host)if(b.activeElement===f)a.top.location.href=d.value}else;}},d)a.addEventListener("message",a.wp.receiveEmbedMessage,!1),b.addEventListener("DOMContentLoaded",c,!1),a.addEventListener("load",c,!1)}(window,document);
                        //--><!]]>
                    </script>
                    <iframe sandbox="allow-scripts" security="restricted" target="_blank" src="https://wordpress.org/plugins/miniorange-otp-verification/embed/" width="95%" height="230" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" class="wp-embedded-content"></iframe>
                </div>
            </div>
        </div>
    </div>
    <script>
        //to set heading name
        jQuery('#mo_openid_page_heading').text('<?php echo mo_sl("What\'s new in miniOrange");?>');
    </script>
 <?php
}
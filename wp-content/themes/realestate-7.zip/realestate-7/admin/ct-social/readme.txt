=== CT Social ===
Contributors: contempoinc
Donate link: 
Tags: contact,personal,business,address,widget
Requires at least: 3.3
Tested up to: 3.4
Stable tag: 3.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An awesome social plugin, featuring all of the most popular social sites (31 to be exact). Choose from 16, 24 & 32px icons, all beautifully designed and pixel perfect.

== Description ==

An awesome social plugin, featuring all of the most popular social sites (31 to be exact). Choose from 16, 24 & 32px icons, all beautifully designed and pixel perfect.

== Installation ==

1. Upload the /ct-social/ folder to the /wp-content/plugins/ directory.
2. Activate the CT Social plugin through the �Plugins� menu in WordPress.
3. Configure your settings via Appearance > Widgets > CT Social.
4. And you�re good to go!